#include "stdio.h"

FILE utilizador();
